
# PhantomSense MVP — Android research prototype

This is an experimental phone-only RF/sensor prototype for the proposed idea:
privacy-preserving environmental sensing without cameras or identity recognition.

## What this MVP actually does
- Collects Android Wi-Fi scan metadata (RSSI/AP count).
- Scans BLE RSSI where permitted.
- Collects accelerometer/gyroscope features.
- Uses Wi-Fi RTT when the phone AND nearby access points support it.
- Renders an abstract, rotating 3D-style signal/occupancy visualization.
- Computes a simple temporal activity score.

## Important scientific limitation
A normal Android app does NOT generally receive raw Wi-Fi CSI/IQ samples from the phone radio.
Wi-Fi scan results and BLE RSSI are not equivalent to a radar image. Therefore this MVP
does NOT claim to reconstruct arbitrary surrounding physical shapes or reliably detect assault.

The next research stage should target hardware/firmware that exposes CSI or other RF
channel measurements, or use supported ranging technologies, then train a neural RF
reconstruction model on controlled data.

## Build
Open the project in Android Studio and run on an Android device.

The app requests nearby-device/location permissions because Android requires them for
the relevant Wi-Fi/BLE workflows.

## Recommended first experiment
1. Test on a phone with Wi-Fi RTT support.
2. Test in a room with multiple RTT-capable APs.
3. Record RTT distances and RF features during controlled movement.
4. Separately collect labeled activity data.
5. Compare normal movement, falls, rapid movement, and simulated struggle.
6. Only after feasibility is demonstrated, develop a learned 3D/RF reconstruction model.

## Why this is useful
The project is intentionally structured as a feasibility MVP rather than pretending that
standard phone APIs already provide a 3D RF camera.


## Build the APK using only your phone

You do not need a computer.

1. Create/sign into a GitHub account in your phone browser.
2. Create a new repository, for example `PhantomSenseMVP`.
3. Upload all files from this project to the repository, including `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab.
5. Select **Build PhantomSense APK**.
6. Tap **Run workflow**.
7. When it finishes, open the workflow run and download the artifact named `PhantomSense-debug-apk`.
8. Extract the downloaded ZIP and install the APK on the OPPO A59 5G.
9. Android may ask you to allow installation from your browser/file manager.

If GitHub's mobile interface makes uploading folders inconvenient, upload the project as a ZIP only if your chosen repository workflow supports extracting it; otherwise upload the individual files/folders.

The resulting debug APK is for personal testing. It is not a Play Store release.
