package com.phantomsense.mvp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.net.wifi.rtt.RangingRequest
import android.net.wifi.rtt.WifiRttManager
import android.os.*
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.hardware.*
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.*
import kotlin.random.Random

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var wifi: WifiManager
    private var rtt: WifiRttManager? = null
    private var ble: BluetoothLeScanner? = null
    private lateinit var visual: PhantomView
    private lateinit var status: TextView
    private lateinit var metrics: TextView

    private val requestCode = 42
    private val featureHistory = ArrayDeque<FloatArray>()
    private var running = false

    private val wifiReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: android.content.Intent?) {
            if (intent?.action != WifiManager.SCAN_RESULTS_AVAILABLE_ACTION) return
            val results = try { wifi.scanResults } catch (_: SecurityException) { emptyList() }
            val strengths = results.take(32).map { it.level.toFloat() }.toFloatArray()
            val feature = floatArrayOf(
                strengths.averageOrZero(),
                strengths.maxOrNull() ?: -100f,
                strengths.minOrNull() ?: -100f,
                strengths.size.toFloat()
            )
            pushFeature(feature)
            status.text = "RF scan: ${results.size} APs"
            updateMapFromSignals(results)
        }
    }

    private val bleCallback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val rssi = result.rssi.toFloat()
            pushFeature(floatArrayOf(rssi, rssi, rssi, 1f))
        }
        override fun onScanFailed(errorCode: Int) {
            status.text = "BLE scan unavailable ($errorCode)"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        wifi = getSystemService(Context.WIFI_SERVICE) as WifiManager
        rtt = getSystemService(Context.WIFI_RTT_RANGING_SERVICE) as? WifiRttManager

        val sensors = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.also {
            sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.also {
            sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            setBackgroundColor(Color.rgb(5, 7, 10))
        }

        val title = TextView(this).apply {
            text = "PHANTOMSENSE"
            textSize = 28f
            setTextColor(Color.WHITE)
        }
        val subtitle = TextView(this).apply {
            text = "Phone-only RF sensing research prototype"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }
        status = TextView(this).apply {
            text = "Ready"
            setTextColor(Color.CYAN)
        }
        metrics = TextView(this).apply {
            text = "Waiting for sensor/RF data…"
            setTextColor(Color.LTGRAY)
        }

        visual = PhantomView(this)
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(metrics)
        root.addView(visual, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = Button(this).apply {
            text = "START SENSING"
            setOnClickListener { startSensing() }
        }
        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener { stopSensing() }
        }
        row.addView(start, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(stop, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        setContentView(root)
        requestPermissionsIfNeeded()
    }

    private fun requestPermissionsIfNeeded() {
        val p = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        )
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        ActivityCompat.requestPermissions(this, p.toTypedArray(), requestCode)
    }

    private fun startSensing() {
        if (!hasPermissions()) {
            requestPermissionsIfNeeded()
            return
        }
        running = true
        status.text = "Sensing…"
        try { registerReceiver(wifiReceiver, android.content.IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) } catch (_: Exception) {}
        try { wifi.startScan() } catch (_: Exception) {}

        val bm = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        ble = bm.adapter?.bluetoothLeScanner
        try { ble?.startScan(bleCallback) } catch (_: Exception) {}

        runRttProbe()
    }

    private fun stopSensing() {
        running = false
        try { unregisterReceiver(wifiReceiver) } catch (_: Exception) {}
        try { ble?.stopScan(bleCallback) } catch (_: Exception) {}
        status.text = "Stopped"
    }

    private fun hasPermissions(): Boolean {
        val loc = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val bleOk = Build.VERSION.SDK_INT < 31 ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        return loc && bleOk
    }

    private fun runRttProbe() {
        val manager = rtt ?: return
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_RTT)) {
            status.text = "Wi‑Fi RTT not supported on this phone"
            return
        }
        val aps = try {
            wifi.scanResults.filter {
                if (Build.VERSION.SDK_INT >= 23) it.is80211mcResponder
                else false
            }.take(8)
        } catch (_: Exception) { emptyList() }
        if (aps.isEmpty()) {
            status.text = "No RTT-capable Wi‑Fi access points found"
            return
        }
        val req = RangingRequest.Builder().addAccessPoints(aps).build()
        manager.startRanging(
            req,
            mainExecutor,
            object : android.net.wifi.rtt.RangingResultCallback() {
                override fun onRangingFailure(code: Int) {
                    status.text = "RTT ranging failed: $code"
                }
                override fun onRangingResults(results: MutableList<android.net.wifi.rtt.RangingResult>) {
                    val good = results.filter { it.status == android.net.wifi.rtt.RangingResult.STATUS_SUCCESS }
                    val points = good.mapIndexed { i, r ->
                        val d = r.distanceMm / 1000f
                        PhantomView.P(d, (i - good.size / 2f) * 0.8f, 0f)
                    }
                    visual.setRttPoints(points)
                    metrics.text = "RTT anchors: ${good.size}  |  mean distance: " +
                            (good.map { it.distanceMm }.averageOrZero() / 1000.0).format(2) + " m"
                }
            }
        )
    }

    private fun updateMapFromSignals(results: List<ScanResult>) {
        val points = results.take(24).mapIndexed { i, r ->
            val a = i * (2.0 * Math.PI / max(1, min(results.size, 24)))
            val radius = (1f + (r.level + 100f) / 100f * 4f)
            PhantomView.P(
                (cos(a) * radius).toFloat(),
                ((r.level + 100f) / 100f * 2f - 1f),
                (sin(a) * radius).toFloat()
            )
        }
        visual.setSignalPoints(points)
    }

    private fun pushFeature(x: FloatArray) {
        if (featureHistory.size > 300) featureHistory.removeFirst()
        featureHistory.addLast(x)
        if (featureHistory.size >= 10) {
            val variance = temporalVariance()
            val score = (variance / 20f).coerceIn(0f, 1f)
            metrics.text = "RF activity score: ${(score * 100).roundToInt()}%  | samples: ${featureHistory.size}"
            visual.activity = score
        }
    }

    private fun temporalVariance(): Float {
        val values = featureHistory.map { it[0] }
        if (values.isEmpty()) return 0f
        val mean = values.average().toFloat()
        return values.map { (it - mean) * (it - mean) }.average().toFloat().let { sqrt(it) }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!running) return
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER || event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            val mag = sqrt(event.values.sumOf { (it * it).toDouble() }).toFloat()
            pushFeature(floatArrayOf(mag, mag, mag, 1f))
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        stopSensing()
        super.onDestroy()
    }

    class PhantomView(context: Context) : View(context) {
        data class P(val x: Float, val y: Float, val z: Float)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var signal = emptyList<P>()
        private var rtt = emptyList<P>()
        var activity = 0f
        private var rot = 0f

        fun setSignalPoints(p: List<P>) { signal = p; invalidate() }
        fun setRttPoints(p: List<P>) { rtt = p; invalidate() }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            paint.style = Paint.Style.STROKE
            paint.color = Color.rgb(25, 40, 55)
            val cx = width / 2f
            val cy = height / 2f
            val s = min(width, height) * 0.11f

            // Abstract 3D wireframe volume
            for (k in 0..8) {
                val q = k / 8f
                val x = cx + (q - .5f) * s * 8f
                val y = cy + (q - .5f) * s * 5f
                c.drawRect(x - s, y - s, x + s, y + s, paint)
            }

            paint.style = Paint.Style.FILL
            signal.forEachIndexed { i, p ->
                val a = rot + i * 0.07f
                val scale = 1f / (1f + abs(p.z) * 0.04f)
                val px = cx + (p.x * cos(a) - p.z * sin(a)) * s * scale
                val py = cy + (p.y - p.z * 0.08f) * s
                paint.color = Color.rgb(0, 190, 255)
                c.drawCircle(px, py, 3f, paint)
            }
            rtt.forEach { p ->
                paint.color = Color.rgb(255, 150, 60)
                val px = cx + p.x * s
                val py = cy + p.y * s
                c.drawCircle(px, py, 8f, paint)
            }

            paint.color = Color.argb(100, 255, 70, 40)
            if (activity > .55f) {
                val radius = s * (1.2f + activity * 2f)
                c.drawCircle(cx, cy, radius, paint)
            }
            rot += 0.005f
            postInvalidateDelayed(33)
        }
    }

    private fun List<Float>.averageOrZero(): Float = if (isEmpty()) 0f else average().toFloat()
    private fun Double.format(n: Int) = "%.${n}f".format(this)
}
